#include <iostream>
using namespace std;

int main() {
    char choice, again;

    do {
        cout << "Pick the number of what you want to do!" << endl;
        cout << "(1) Basic Pricing Decision" << endl;
        cout << "(2) Weather-Based Discounts" << endl;
        cout << "(3) Inventory Check" << endl;
        cout << "(4) Bulk Purchase Discount" << endl;
        cout << "(5) Player Movement" << endl;
        cout << "Enter Choice: ";
        cin >> choice;
        cout << endl;

        switch (choice) {
            case '1': {
                int money;
                cout << "How much money do you have? ";
                cin >> money;

                if (money >= 1) {
                    cout << "We have lemons! And we're making YOU a lemonade." << endl;
                } else {
                    cout << ":(( you need more money..." << endl;
                }
                break;
            }

            case '2': {
                int temperature;
                cout << "How's the weather today (°C)? ";
                cin >> temperature;

                if (temperature >= 30) {
                    cout << "AC is on~ And lemonades are $0.80 only!" << endl;
                } else {
                    cout << "Perfect weather for a fresh $1 lemonade." << endl;
                }
                break;
            }

            case '3': {
                int Sugar, Lemons;
                cout << "Let's make LEMONADES! How much do you have?" << endl;

                cout << "Sugar: ";
                cin >> Sugar;
                cout << "Lemons: ";
                cin >> Lemons;

                if (Sugar != 0 && Lemons != 0) {
                    cout << "Life gave you LEMONS, time to make a lemonade~" << endl;
                } else {
                    cout << "Looks like you need more ingredients..." << endl;
                }
                break;
            }

            case '4': {
                int cup;
                double discount;

                cout << "We know you love our LEMONADES! So we'll let you have more for less~" << endl;
                cout << "For 5–9 cups, you'll get a 10% discount." << endl;
                cout << "For 10 cups or more, a WHOPPING 20% DISCOUNT!" << endl;
                cout << endl;

                cout << "So, how many cups would you like? ";
                cin >> cup;

                if (cup >= 1 && cup <= 4) {
                    cout << "Total cost: $" << cup << endl;
                } else if (cup >= 5 && cup <= 9) {
                    discount = cup - (cup * 0.10);
                    cout << "Total cost: $" << discount << endl;
                } else {
                    discount = cup - (cup * 0.20);
                    cout << "Total cost: $" << discount << endl;
                }
                break;
            }

            case '5': {
                int x = 0, y = 0;
                char move, move1;

                cout << "Let's move!" << endl;

                do {
                    cout << "EAST (W)? WEST (S)? NORTH (A)? SOUTH (D)? ";
                    cin >> move;

                    switch (move) {
                        case 'W':
                        case 'w': y += 1; break;
                        case 'S':
                        case 's': y -= 1; break;
                        case 'A':
                        case 'a': x -= 1; break;
                        case 'D':
                        case 'd': x += 1; break;
                        default: cout << "THAT PLACE CANNOT BE DETECTED!" << endl;
                    }

                    cout << "The location of the player is (" << x << "," << y << ")" << endl;
                    cout << endl;
                    cout << "Do we move or end it here? Y/N? ";
                    cin >> move1;
                    cout << endl;

                } while (move1 == 'Y' || move1 == 'y');

                cout << "Game ended. Final location: (" << x << "," << y << ")" << endl;
                break; // ✅ instead of return 0
            }

            default:
                cout << "Invalid choice! Try again." << endl;
                break;
        }

        cout << endl << "Do you want to try another program? (Y/N): ";
        cin >> again;
        cout << endl;

    } while (again == 'Y' || again == 'y');

    cout << "Program ended. Goodbye!" << endl;
    return 0;
}
#include <iostream>
using namespace std;

int main() {
    
	int Sugar;
	int Lemons;
	
	cout << "Let's make LEMONADES! How much do you have?";
	cout << endl;
	
	cout << "Sugar:";
	cin >> Sugar;
	cout << "Lemons:";
	cin >> Lemons;
	
	if (Sugar && Lemons != 0) {
		cout << "Life gave you LEMONS, time to make a lemonade~";
	}
	else {
		cout << "Looks like you need more ingredients...";
	}

	return 0;
}
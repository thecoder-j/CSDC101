#include <iostream>
using namespace std;

int main() {
    
	int cup;
	double discount;
	
	cout << "We know you love our LEMONADES! So we'll let you have more for less~";
	cout << endl;
	cout << endl;
	
	cout << "For 5-9 cups you'll get a 10% discount";
	cout << endl;
	
	cout << "...But for 10 cups or more, A WHOPPING 20% DISCOUNT!";
	cout << endl;
	cout << endl;
	
	cout << "So, how many cups would you like? ";
	cin >> cup;
	
	if (cup >= 1 && cup <= 4) {
        cout << "Total cost: $";
        cout << cup;
	}
	else if (cup >= 5 && cup <= 9) {
	    discount = (cup - (cup*.10));
	    cout << "Total cost: $";
	    cout << discount;
	}
	else {
	    discount = (cup - (cup*.20));
	    cout << "Total cost: $";
	    cout << discount;
	}
	    
	return 0;
}
#include <iostream>
using namespace std;

int main() {
    int x = 0;
    int y = 0;
    char move, move1;

    cout << "Let's move!" << endl;

    do {
        cout << "EAST (W)? WEST (S)? NORTH (A)? SOUTH (D)? ";
        cin >> move;

        if (move == 'W' || move == 'w') {
            y += 1;
        } 
        else if (move == 'S' || move == 's') {
            y -= 1;
        } 
        else if (move == 'A' || move == 'a') {
            x -= 1;
        } 
        else if (move == 'D' || move == 'd') {
            x += 1;
        } 
        else {
            cout << "THAT PLACE CANNOT BE DETECTED!" << endl;
        }

        cout << "The location of the player is (" << x << "," << y << ")" << endl;
        cout << endl;

        cout << "Do we move or end it here? Y/N? ";
        cin >> move1;
        cout << endl;

    } while (move1 == 'Y' || move1 == 'y');

    cout << "Game ended. Final location: (" << x << "," << y << ")" << endl;

    return 0;
}
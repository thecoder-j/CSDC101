#include <iostream>
using namespace std;

int main() {
    
	int temperature;
	
	cout << "How's the weather today?";
	cout << endl;
	
	cin >> temperature;
	if (temperature >= 30) {
		cout << "AC is on~ And lemonades are $0.80 only!";
	}
	else {
		cout << "Perfect weather for a fresh $1 lemonade";
	}

	return 0;
}
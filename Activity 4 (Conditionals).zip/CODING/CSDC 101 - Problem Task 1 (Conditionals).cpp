#include <iostream>
using namespace std;

int main(){
    int money;
    cout << "How much money do you have?";
    cout << endl;
    cin >> money;
    if (money >= 1){
        cout << "We have lemons! And we're making YOU a lemonade.";
    }
    else {
        cout << ":(( you need more money...";
    }
    
    return 0;
}